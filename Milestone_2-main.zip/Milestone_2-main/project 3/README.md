# Todo app using react + vite

## Functionality
- Add task - you can add task by clickng Add button
- Status - update task status pending to comleted & completed to pending
- Remove - remove task from the task list


## Project Setup
To run project locally
- Clone repo
- `cd project 3` to enter in 3rd project
- `npm install` in root directory
- `npm run dev` to start file


## Project Overview
![Capture4](https://github.com/bhalaniyatin2402/Milestone_2/assets/126591717/79d655dc-d884-4ce0-ba9f-9a5444b69b96)
