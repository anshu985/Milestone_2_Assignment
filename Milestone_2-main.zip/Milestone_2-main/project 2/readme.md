# Movie Search App

## Features
- Search - search and filter movie using HTML, CSS and Javascript

## Project Overview
![Capture3](https://github.com/bhalaniyatin2402/Milestone_2/assets/126591717/26cb3629-feee-4cee-875a-794666520e29)
